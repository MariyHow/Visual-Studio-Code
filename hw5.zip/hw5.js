var rootStyle;

function createCSSVariables() {
    var root = document.querySelector(":root");
    root.style.setProperty("font-size", "2vw");
    root.style.setProperty("--fivepx", "0.31rem");
    root.style.setProperty("--fiftypx", "3.125rem");

    rootStyle = getComputedStyle(root);
}

function createBanner(node) {
    var banner = document.getElementById("header");
    var headerObject = document.createElement("header");
    var headerText = document.createTextNode("Welcome to my webpage");

    headerObject.appendChild(headerText);
    headerObject.setAttribute("class", "jumbotron text-center");

    headerObject.style.backgroundColor = "gray";
    headerObject.style.color = "white";
    headerObject.style.fontSize = "2rem";
    headerObject.style.paddingTop = "3rem"; 
    headerObject.style.class            ="container";

    node.appendChild(headerObject);
}

function createServices() {
    var servicesContainer = document.getElementById("services");
    var services = [
        { title: "Web Design", description: "Our designers make websites that will exceed your needs and perform all your necessity" },
        { title: "Graphic Design", description: "Our designers can make your imagination come to life" },
        { title: "Digital Marketing", description: "We are able to satisfy the needs of our customers." }
    ];

    services.forEach(function(service) {
        var col = document.createElement("div");
        col.setAttribute("class", "col-md-4");
        var card = document.createElement("div");
        card.setAttribute("class", "card");
        var cardBody = document.createElement("div");
        cardBody.setAttribute("class", "card-body");

        var title = document.createElement("h5");
        title.setAttribute("class", "card-title");
        title.textContent = service.title;
        var description = document.createElement("p");
        description.setAttribute("class", "card-text");
        description.textContent = service.description;

        cardBody.appendChild(title);
        cardBody.appendChild(description);
        card.appendChild(cardBody);
        col.appendChild(card);
        servicesContainer.appendChild(col);
    });
}

function createTestimonials() {
    var testimonialsContainer = document.getElementById("testimonials");
    var blockquote = document.createElement("blockquote");
    blockquote.setAttribute("class", "blockquote mb-0");
    var paragraph = document.createElement("p");
    paragraph.textContent = "\"Great service! I am satisfied with my product.\"";
    var footer = document.createElement("footer");
    footer.setAttribute("class", "blockquote-footer");
    footer.textContent = "John Smith";

    blockquote.appendChild(paragraph);
    blockquote.appendChild(footer);
    testimonialsContainer.appendChild(blockquote);
}

function createProjects() {
    var projectsContainer = document.getElementById("projects");
    var projects = ["project1.jpg", "project2.jpg", "project3.jpg"];

    projects.forEach(function(project) {
        var col = document.createElement("div");
        col.setAttribute("class", "col-md-4");
        var image = document.createElement("img");
        image.setAttribute("src", project);
        image.setAttribute("class", "img-fluid");
        image.setAttribute("alt", "Project Image");

        col.appendChild(image);
        projectsContainer.appendChild(col);
    });
}

document.addEventListener("DOMContentLoaded", function() {
    createCSSVariables();
    createBanner();
    createServices();
    createTestimonials();
    createProjects();
});
